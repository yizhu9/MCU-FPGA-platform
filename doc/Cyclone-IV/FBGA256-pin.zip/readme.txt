File Extension			Description

	BAK		Backup file for PCB layout
	BMK		Bottom mask gerber file
	BOT		Bottom layer gerber file
	BPS		Bottom paste gerber file
	BSK		Bottom silk gerber file
	drl		N/C drill format file
	gnd		Ground plane gerber file
	Accel		PCB layout file from ACCEL software
	pcb		Layout file from the ACCEL layout tool
	TMK		Top mask gerber file
	TOP		Top layer gerber file
	TPS		Top paste gerber file
	TSK		Top silk gerber file
	VCCINT		VCCINT plane gerber file
	VCCIO		VCCIO plane gerber file


Specifications for 256-, 484- & 672-Pin FineLine BGA Layout Files 
Specification Value 
I/O pad on PCB Pad Size: 15.7 mils 
Via Pad Size: 16 mils 
 Plated through-hole: 8 mils 
Trace width 5 mils 
Space width 5 mils 


					